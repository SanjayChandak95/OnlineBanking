package com.cg.entities;

import java.io.Serializable;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="transaction_details")
public class TransactionBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="transaction_Id")
	private long transactionId;
	@Column(name="transaction_Description")
	private String transactionDescription;
	@Column(name="transaction_Amount")
	private double transactionAmount;
	@Column(name="transaction_Date")
	private Date transactionDate;
	@Column(name="account_Number")
	private String accountnumber ;
	
	
	public TransactionBean(long transactionId, String transactionDescription,
			double transactionAmount, Date transactionDate, String accountnumber) {
		super();
		this.transactionId = transactionId;
		this.transactionDescription = transactionDescription;
		this.transactionAmount = transactionAmount;
		this.transactionDate = transactionDate;
		this.accountnumber = accountnumber;
	}
	public String getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionDescription() {
		return transactionDescription;
	}
	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	
	
	

}
