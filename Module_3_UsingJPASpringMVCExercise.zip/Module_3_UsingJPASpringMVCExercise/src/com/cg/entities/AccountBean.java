package com.cg.entities;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="account_Details")
public class AccountBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="account_Number")
	private String accountNumber;
	@Column(name="customer_Name")
	private String customerName;
	@Column(name="account_Type")
	private String accountType;
	@Column(name="account_Location")
	private String accountLocation;
	@Column(name="Balance")
	private double accountBalance;
	
	
	public AccountBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public AccountBean(String accountNumber, String customerName,
			String accountType, String accountLocation, double accountBalance) {
		super();
		this.accountNumber = accountNumber;
		this.customerName = customerName;
		this.accountType = accountType;
		this.accountLocation = accountLocation;
		this.accountBalance = accountBalance;
	}


	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountLocation() {
		return accountLocation;
	}
	public void setAccountLocation(String accountLocation) {
		this.accountLocation = accountLocation;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	
	

}
