package com.cg.dao;

import java.util.ArrayList;

import com.cg.entities.AccountBean;
import com.cg.exception.BankingException;

public interface BankingDao {

	ArrayList<AccountBean> selectBillDetails(String custName) throws BankingException;
	int update(String accNum,double balance) throws BankingException;
	int insert(String accNum,double balance) throws BankingException;

}