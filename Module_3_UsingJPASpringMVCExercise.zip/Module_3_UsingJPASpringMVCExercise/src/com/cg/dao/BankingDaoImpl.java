package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entities.AccountBean;
import com.cg.exception.BankingException;

@Repository
@Transactional
public class BankingDaoImpl implements BankingDao {

	//Below annotation is required to inject auto created entityManager from entityManagerFactory
	@PersistenceContext
	private EntityManager entityManager;

	public int insert(String accNum,double balance) throws BankingException{
		Query query = entityManager.createNativeQuery("INSERT INTO transaction_details VALUES(transaction_id_seq.NEXTVAL,'ATM debit',"+balance+",sysdate,'"+accNum+"')");
		int rec = query.executeUpdate();
		System.out.println(rec);
		return rec;
	}


	@Override
	public ArrayList<AccountBean> selectBillDetails(String custName) throws BankingException{
		TypedQuery<AccountBean> query = entityManager.createQuery("SELECT e FROM AccountBean e where e.customerName='"+custName+"'", AccountBean.class);
		return (ArrayList<AccountBean>) query.getResultList();
	}

	@Override
	public int update(String accNum,double balance) throws BankingException{
		Query query = entityManager.createNativeQuery("UPDATE account_details SET balance=(balance-"+balance+") WHERE account_number='"+accNum+"' AND (balance-"+balance+")>0");
		int rec = query.executeUpdate();
		return rec;
	}

}