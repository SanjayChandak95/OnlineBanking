package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.BankingDao;
import com.cg.entities.AccountBean;
import com.cg.exception.BankingException;

@Service
  
public class BankingServiceImpl implements BankingService {

	@Autowired
	private BankingDao traineeDaoImpl;
	
	
	/* (non-Javadoc)
	 * @see com.cg.service.EmployeeService#save(com.cg.entities.Employee)
	 */
	@Override
	public ArrayList<AccountBean> selectBillDetails(String custName) throws BankingException{
		return traineeDaoImpl.selectBillDetails(custName);
	}
	
	@Override
	public int insert(String accNum,double balance) throws BankingException{
		return traineeDaoImpl.insert(accNum, balance);
	}
	
	@Override
	public int update(String accNum,double balance) throws BankingException{
		return traineeDaoImpl.update(accNum, balance);
	}
	
}