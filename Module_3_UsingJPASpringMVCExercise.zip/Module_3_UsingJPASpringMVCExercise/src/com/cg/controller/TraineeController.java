package com.cg.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.AccountBean;
import com.cg.exception.BankingException;
import com.cg.service.BankingService;

@Controller
public class TraineeController {

	@Autowired
	private BankingService traineeService;

	@RequestMapping("/checkUser.htm")
	public String getMainPage(@RequestParam("custname") String custName,Model model) throws BankingException{
		ArrayList<AccountBean> list= traineeService.selectBillDetails(custName);
		if(list.size()>0){
			model.addAttribute("accList",list);
			model.addAttribute("custName",custName);
			return "AccountInfo";
		}else{
			return "CustomerError";
		}
	}
	
	@RequestMapping("/debitAmount")
	public String debitAmount(@RequestParam("accNum") String accNum,Model model){
		model.addAttribute("accNum", accNum);
		return "DebitAmount";
	}
	
	@RequestMapping("/debit")
	public String debit(@RequestParam("accNum") String accNum,@RequestParam("atmDebit") int atmDebit,Model model){
	try {
		if(atmDebit>0)
		{
		if(traineeService.update(accNum, atmDebit)!=0) // validate amount can be withdraw or not and also upadte account_details if withdraw take place
		{
			if(traineeService.insert(accNum,atmDebit)!=0) // check insertion
			{
				model.addAttribute("accNum", accNum);
				model.addAttribute("atmDebit", atmDebit);
				return "TransactionSuccess";
			}
		}
		else{
			model.addAttribute("Error", "Your Balance is too low to withdraw this amount");
			return "CustomerError";
		}
		}
		else
		{
			model.addAttribute("Error", "Amount can not be nagative or zero");
			return "CustomerError";
		}
		
	} catch (BankingException e) {
		model.addAttribute("Error", "Error with database");
		return "CustomerError";
	}
	return null;
} 
}